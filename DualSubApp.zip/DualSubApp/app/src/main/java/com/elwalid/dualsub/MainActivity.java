package com.elwalid.dualsub;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    static final int REQ_PROJ = 11, REQ_PERM = 12;

    private static final String[] MODE_NAMES = {"أفلام ومسلسلات", "أخبار وبث مباشر", "وثائقي وبرامج حوارية", "عام"};
    private static final String[] LANG_NAMES = {"تلقائي (يكتشفها التطبيق)", "الإنجليزية", "الفرنسية", "الإسبانية", "التركية",
            "الألمانية", "الروسية", "الإيطالية", "البرتغالية", "اليابانية", "الكورية", "الصينية", "الهندية", "الفارسية", "العربية"};
    private static final String[] LANG_CODES = {"", "en", "fr", "es", "tr", "de", "ru", "it", "pt", "ja", "ko", "zh", "hi", "fa", "ar"};

    private EditText keyEt, gkeyEt, langEt, segEt, fontEt;
    private Spinner modeSp, srcSp;
    private CheckBox origCb, lookCb, expCb;
    private TextView status;
    private SharedPreferences sp;
    private LinearLayout root;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("cfg", MODE_PRIVATE);

        int pad = (int) (20 * getResources().getDisplayMetrics().density);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(pad, pad, pad, pad);
        header.setBackground(rounded(0xFF0F4C81, 18, 0));

        TextView title = new TextView(this);
        title.setText("ترجمة صوت أي فيديو (برو 3.4.3)");
        title.setTextSize(24);
        title.setTextColor(Color.WHITE);
        header.addView(title);

        TextView help = new TextView(this);
        help.setText("يلتقط صوت الهاتف من أي تطبيق أو متصفح، ويحوّله إلى نص، ثم يعرض ترجمته فوق الشاشة. "
                + "يمكنك سحب الترجمة بإصبعك لتحريكها.");
        help.setTextColor(0xFFCFE3F5);
        help.setTextSize(14);
        help.setPadding(0, pad / 2, 0, 0);
        header.addView(help);
        root.addView(header);

        keyEt = field("المفتاح الأول (Groq يبدأ بـ gsk_، أو Gemini يبدأ بـ AIza)",
                sp.getString("key", ""), true);
        gkeyEt = field("المفتاح الثاني (اختياري): ضع هنا المفتاح الآخر. الترتيب لا يهم، وينتقل التطبيق بينهما تلقائياً",
                sp.getString("gkey", ""), true);
        modeSp = spinner("ماذا تشاهد؟ (يعمل فقط مع الميزات التجريبية أدناه)", MODE_NAMES, sp.getInt("mode", 3));
        int srcIdx = 0;
        String savedSrc = sp.getString("src", "");
        for (int i = 0; i < LANG_CODES.length; i++) if (LANG_CODES[i].equals(savedSrc)) srcIdx = i;
        srcSp = spinner("لغة الكلام في الفيديو (اختيار اللغة يرفع الدقة، والتلقائي يكتشفها وحده)", LANG_NAMES, srcIdx);
        langEt = field("لغة الترجمة: رمزها (ar للعربية)", sp.getString("lang", "ar"), true);
        segEt = field("أقصى طول للجملة بالثواني (من 3 إلى 10). الأقصر أسرع، والأطول أدق",
                String.valueOf(sp.getInt("maxseg5", 5)), false);
        segEt.setInputType(InputType.TYPE_CLASS_NUMBER);
        fontEt = field("حجم خط الترجمة (من 12 إلى 32)",
                String.valueOf(sp.getInt("fsize", 20)), false);
        fontEt.setInputType(InputType.TYPE_CLASS_NUMBER);

        origCb = new CheckBox(this);
        origCb.setText("إظهار النص الأصلي فوق الترجمة");
        origCb.setChecked(sp.getBoolean("showorig", false));
        root.addView(origCb);

        lookCb = new CheckBox(this);
        lookCb.setText("انتظار الجملة التالية قبل الترجمة (يعمل فقط مع الميزات التجريبية)");
        lookCb.setChecked(sp.getBoolean("lookahead", false));
        root.addView(lookCb);

        expCb = new CheckBox(this);
        expCb.setText("ميزات 3.3 التجريبية (تقطيع ذكي + مرشحات + أسلوب حسب النوع). الأفضل تركها مغلقة، فالافتراضي هو سلوك 3.0");
        expCb.setChecked(sp.getBoolean("exp", false));
        root.addView(expCb);

        button("السماح بالعرض فوق التطبيقات", 0xFF546E7A, v -> openOverlaySettings());
        button("فحص المفاتيح", 0xFF0F4C81, v -> checkKeys());
        button("بدء الترجمة", 0xFF2E7D32, v -> startFlow());
        button("نسخ سجل التشخيص (أرسله لي)", 0xFF6A1B9A, v -> {
            String log = DiagLog.tail(60000);
            if (log.isEmpty()) { Toast.makeText(this, "السجل فارغ. شغّل الترجمة أولاً.", Toast.LENGTH_LONG).show(); return; }
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("dualsub-log", log));
            Toast.makeText(this, "تم نسخ السجل (" + log.length() + " حرف). الصقه في المحادثة.", Toast.LENGTH_LONG).show();
        });
        button("مسح السجل", 0xFF757575, v -> {
            DiagLog.clear();
            Toast.makeText(this, "تم مسح السجل", Toast.LENGTH_SHORT).show();
        });
        button("إيقاف", 0xFFC62828, v -> {
            Intent i = new Intent(this, TranslateService.class);
            i.setAction(TranslateService.ACTION_STOP);
            startService(i);
            status.setText("تم الإيقاف");
        });

        status = new TextView(this);
        status.setGravity(Gravity.START);
        status.setPadding(0, pad / 2, 0, 0);
        root.addView(status);

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(0xFFF4F6F8);
        sv.addView(root);
        setContentView(sv);
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private GradientDrawable rounded(int fill, int radiusDp, int strokeColor) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        if (strokeColor != 0) g.setStroke(dp(1), strokeColor);
        return g;
    }

    private Button button(String text, int color, View.OnClickListener l) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setAllCaps(false);
        btn.setTextColor(Color.WHITE);
        btn.setTextSize(16);
        btn.setBackground(rounded(color, 12, 0));
        btn.setOnClickListener(l);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(52));
        p.topMargin = dp(12);
        root.addView(btn, p);
        return btn;
    }

    private Spinner spinner(String label, String[] items, int selected) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextSize(13);
        t.setTextColor(0xFF37474F);
        t.setPadding(0, dp(14), 0, dp(4));
        root.addView(t);
        Spinner sp2 = new Spinner(this);
        sp2.setBackground(rounded(Color.WHITE, 10, 0xFFCCD3DA));
        sp2.setPadding(dp(8), dp(10), dp(8), dp(10));
        ArrayAdapter<String> ad = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items);
        sp2.setAdapter(ad);
        sp2.setSelection(Math.max(0, Math.min(items.length - 1, selected)));
        root.addView(sp2);
        return sp2;
    }

    private EditText field(String label, String value, boolean ltr) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextSize(13);
        t.setTextColor(0xFF37474F);
        t.setPadding(0, dp(14), 0, dp(4));
        root.addView(t);
        EditText e = new EditText(this);
        e.setSingleLine(true);
        e.setBackground(rounded(Color.WHITE, 10, 0xFFCCD3DA));
        e.setPadding(dp(12), dp(10), dp(12), dp(10));
        if (ltr) e.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        e.setText(value);
        root.addView(e);
        return e;
    }

    private static int parseInt(String s, int def) {
        try { return Integer.parseInt(s.trim()); } catch (Exception e) { return def; }
    }

    private void saveCfg() {
        String lang = langEt.getText().toString().trim();
        if (lang.isEmpty()) lang = "ar";
        int seg = Math.max(3, Math.min(10, parseInt(segEt.getText().toString(), 5)));
        int fs = Math.max(12, Math.min(32, parseInt(fontEt.getText().toString(), 19)));
        sp.edit()
                .putString("key", keyEt.getText().toString().trim())
                .putString("gkey", gkeyEt.getText().toString().trim())
                .putString("src", LANG_CODES[Math.max(0, Math.min(LANG_CODES.length - 1, srcSp.getSelectedItemPosition()))])
                .putInt("mode", Math.max(0, modeSp.getSelectedItemPosition()))
                .putString("lang", lang)
                .putInt("maxseg5", seg)
                .putInt("fsize", fs)
                .putBoolean("showorig", origCb.isChecked())
                .putBoolean("lookahead", lookCb.isChecked())
                .putBoolean("exp", expCb.isChecked())
                .apply();
    }

    /** يفحص المفاتيح فعلياً ويعرض النتيجة، فتعرف إن كانت صالحة قبل أن تبدأ. */
    private void checkKeys() {
        saveCfg();
        status.setText("جارٍ فحص المفاتيح...");
        final String k1 = sp.getString("key", "");
        final String k2 = sp.getString("gkey", "");
        new Thread(() -> {
            String groq = "", gem = "";
            for (String k : new String[]{k1, k2}) {
                if (k.isEmpty()) continue;
                if (k.startsWith("gsk_")) groq = k;
                else gem = k;
            }
            String r1 = groq.isEmpty() ? "Groq: لا يوجد مفتاح"
                    : "Groq: " + probe("https://api.groq.com/openai/v1/models", "Authorization", "Bearer " + groq);
            String r2 = gem.isEmpty() ? "Gemini: لا يوجد مفتاح"
                    : "Gemini: " + probe("https://generativelanguage.googleapis.com/v1beta/models?pageSize=1", "x-goog-api-key", gem);
            final String msg = r1 + "\n" + r2;
            runOnUiThread(() -> status.setText(msg));
        }).start();
    }

    private static String probe(String url, String header, String value) {
        try {
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(8000);
            c.setReadTimeout(8000);
            c.setRequestProperty(header, value);
            c.setRequestProperty("User-Agent", "Mozilla/5.0");
            int code = c.getResponseCode();
            if (code == 200) return "المفتاح صالح ✓";
            if (code == 400 || code == 401 || code == 403) return "المفتاح غير صالح ✗ (" + code + ")";
            if (code == 429) return "المفتاح صالح لكنه بلغ الحد المؤقت (429)";
            return "رد غير متوقع (" + code + ")";
        } catch (Exception e) {
            return "تعذّر الاتصال بالإنترنت (" + e.getClass().getSimpleName() + ")";
        }
    }

    private void openOverlaySettings() {
        Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName()));
        startActivity(i);
    }

    private void startFlow() {
        saveCfg();
        if (sp.getString("key", "").isEmpty() && sp.getString("gkey", "").isEmpty()) {
            Toast.makeText(this, "أدخل المفتاح أولاً", Toast.LENGTH_LONG).show();
            return;
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "اسمح بالعرض فوق التطبيقات ثم ارجع", Toast.LENGTH_LONG).show();
            openOverlaySettings();
            return;
        }
        List<String> need = new ArrayList<>();
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.RECORD_AUDIO);
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.POST_NOTIFICATIONS);
        if (need.isEmpty()) askProjection();
        else requestPermissions(need.toArray(new String[0]), REQ_PERM);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code != REQ_PERM) return;
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
            askProjection();
        else
            status.setText("إذن الصوت مطلوب لالتقاط صوت الفيديو");
    }

    private void askProjection() {
        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_PROJ);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_PROJ) return;
        if (res != RESULT_OK || data == null) {
            status.setText("لم تتم الموافقة على التقاط الصوت");
            return;
        }
        Intent i = new Intent(this, TranslateService.class);
        i.setAction(TranslateService.ACTION_START);
        i.putExtra("code", res);
        i.putExtra("data", data);
        startForegroundService(i);
        status.setText("يعمل الآن. افتح أي فيديو وستظهر الترجمة فوق الشاشة.");
        moveTaskToBack(true);
    }
}
