package com.elwalid.dualsub;

/**
 * يحتجز جملة واحدة حتى تصل التي بعدها، ليُترجم الأولى مع معرفة ما يليها.
 * إن لم تصل جملة جديدة خلال المهلة تُترجم المحتجزة وحدها.
 * تُستعمل من خيط الشبكة الواحد فقط.
 */
final class Lookahead {
    interface Out {
        void translate(String text, String next, double secs);
    }

    private String held;
    private double heldSecs;
    private long token;

    /** وصلت جملة جديدة: تُترجم المحتجزة (إن وُجدت) ثم تُحتجز الجديدة. يعيد رمز المهلة. */
    long onNew(String text, double secs, Out out) {
        String prev = held;
        double prevSecs = heldSecs;
        held = text;
        heldSecs = secs;
        long tk = ++token;
        if (prev != null) out.translate(prev, text, prevSecs);
        return tk;
    }

    /** انتهت المهلة: نترجم المحتجزة وحدها، بشرط ألا تكون قد تغيرت. */
    boolean flush(long tk, Out out) {
        if (held == null || tk != token) return false;
        String h = held;
        double s = heldSecs;
        held = null;
        token++;
        out.translate(h, null, s);
        return true;
    }

    void clear() {
        held = null;
        token++;
    }
}
