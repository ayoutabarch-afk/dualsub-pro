package com.elwalid.dualsub;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * سجل تشخيص يُحفظ في ملف داخل التطبيق، ليُنسخ ويُرسل عند البحث عن سبب خلل.
 * لا يُسجَّل فيه أي مفتاح. يحتفظ بآخر ~100 كيلوبايت فقط.
 */
final class DiagLog {
    private DiagLog() {}

    private static final long MAX_BYTES = 200_000;
    private static final int KEEP_BYTES = 100_000;
    private static File file;

    static synchronized void init(File dir) {
        file = new File(dir, "diag.txt");
    }

    /** يقصّ النص ويحوّل الأسطر إلى مسافات ليبقى كل حدث في سطر واحد. */
    static String clip(String s) {
        if (s == null) return "";
        String t = s.replace('\n', ' ').replace('\r', ' ').trim();
        return t.length() > 300 ? t.substring(0, 300) + "…" : t;
    }

    static synchronized void log(String line) {
        if (file == null) return;
        try {
            String ts = new SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(new Date());
            FileOutputStream fo = new FileOutputStream(file, true);
            try {
                fo.write((ts + " " + line + "\n").getBytes("UTF-8"));
            } finally {
                fo.close();
            }
            if (file.length() > MAX_BYTES) trim();
        } catch (Exception ignored) {
        }
    }

    private static byte[] readAll() throws Exception {
        if (file == null || !file.exists()) return new byte[0];
        FileInputStream in = new FileInputStream(file);
        try {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            return bo.toByteArray();
        } finally {
            in.close();
        }
    }

    /** نبقي آخر KEEP_BYTES بدءاً من أول سطر كامل (البايت 0x0A لا يقع داخل حرف متعدد البايت). */
    private static void trim() throws Exception {
        byte[] all = readAll();
        int from = Math.max(0, all.length - KEEP_BYTES);
        while (from < all.length && from > 0 && all[from - 1] != '\n') from++;
        FileOutputStream fo = new FileOutputStream(file, false);
        try {
            fo.write(all, from, all.length - from);
        } finally {
            fo.close();
        }
    }

    /** آخر maxChars حرف من السجل (من بداية سطر كامل). */
    static synchronized String tail(int maxChars) {
        try {
            String s = new String(readAll(), "UTF-8");
            if (s.length() <= maxChars) return s;
            int from = s.length() - maxChars;
            int nl = s.indexOf('\n', from);
            return "…\n" + (nl >= 0 ? s.substring(nl + 1) : s.substring(from));
        } catch (Exception e) {
            return "";
        }
    }

    static synchronized void clear() {
        try {
            if (file != null) file.delete();
        } catch (Exception ignored) {
        }
    }
}
