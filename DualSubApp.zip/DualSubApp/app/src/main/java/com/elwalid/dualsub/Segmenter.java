package com.elwalid.dualsub;

import java.io.ByteArrayOutputStream;
import java.util.ArrayDeque;
import java.util.ArrayList;

/**
 * يقطّع الصوت (إطارات من 100 ملّي ثانية) إلى جمل:
 * - ينتهي المقطع عند وقفة طبيعية.
 * - إن طال الكلام بلا وقفة، يُقطع عند أهدأ لحظة في آخره، ويُرحَّل الباقي إلى المقطع التالي،
 *   فلا تنقطع الكلمة في منتصفها.
 * - يقلّم الصمت الزائد في نهاية المقطع، ويتجاهل المقاطع التي ليس فيها كلام كافٍ.
 * لا يعتمد على أندرويد، فيمكن اختباره بالكامل.
 */
final class Segmenter {
    static final int PRE_ROLL = 6;      // إطارات قبل بداية الكلام (0.6 ثانية، حتى لا يُقصّ أول حرف)
    static final int TAIL_KEEP = 3;     // أقصى صمت يُترك في نهاية المقطع
    static final int MIN_SPEECH = 3;    // أقل عدد إطارات كلام ليُرسل المقطع (0.3 ثانية)
    static final int CUT_WINDOW = 12;   // نافذة البحث عن أهدأ لحظة عند القطع الإجباري

    private final int minFrames, endSilence, softCut, softSilence, maxFrames;
    private final boolean smart;   // false = السلوك الكلاسيكي: قطع صلب عند الحد، بلا تقليم ولا تجاهل مقاطع قصيرة

    private final ArrayList<byte[]> frames = new ArrayList<>();
    private final ArrayList<Double> energy = new ArrayList<>();
    private final ArrayList<Boolean> voiced = new ArrayList<>();
    private final ArrayDeque<byte[]> pre = new ArrayDeque<>();
    private boolean started = false;
    private int silent = 0;     // عدد الإطارات الصامتة المتتالية في آخر المقطع
    private int lead = 0;       // عدد إطارات ما قبل البداية داخل القائمة

    Segmenter(int minFrames, int endSilence, int softCut, int softSilence, int maxFrames) {
        this(minFrames, endSilence, softCut, softSilence, maxFrames, true);
    }

    Segmenter(int minFrames, int endSilence, int softCut, int softSilence, int maxFrames, boolean smart) {
        this.smart = smart;
        this.minFrames = minFrames;
        this.endSilence = endSilence;
        this.softCut = softCut;
        this.softSilence = softSilence;
        this.maxFrames = smart ? Math.max(maxFrames, minFrames + 2) : maxFrames;
    }

    /** يمرر إطاراً جديداً. يعيد مقطعاً كاملاً (PCM) إن اكتمل، وإلا null. */
    byte[] push(byte[] f, double rms, boolean speech) {
        if (!started) {
            if (!speech) {
                pre.addLast(f);
                if (pre.size() > PRE_ROLL) pre.removeFirst();
                return null;
            }
            started = true;
            frames.clear();
            energy.clear();
            voiced.clear();
            lead = pre.size();
            for (byte[] p : pre) add(p, 0.0, false);
            pre.clear();
            add(f, rms, true);
            silent = 0;
            return null;
        }
        add(f, rms, speech);
        silent = speech ? 0 : silent + 1;
        int count = frames.size() - lead;
        int need = count >= softCut ? softSilence : endSilence;
        if (count >= minFrames && silent >= need) return finish();
        if (count >= maxFrames) return forcedCut();
        return null;
    }

    private void add(byte[] f, double rms, boolean speech) {
        frames.add(f);
        energy.add(rms);
        voiced.add(speech);
    }

    private int voicedCount(int from, int to) {
        int n = 0;
        for (int i = from; i < to; i++) if (voiced.get(i)) n++;
        return n;
    }

    private static byte[] join(ArrayList<byte[]> list, int from, int to) {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        for (int i = from; i < to; i++) bo.write(list.get(i), 0, list.get(i).length);
        return bo.toByteArray();
    }

    private void reset() {
        started = false;
        frames.clear();
        energy.clear();
        voiced.clear();
        silent = 0;
        lead = 0;
    }

    /** نهاية طبيعية: نقلّم الصمت الزائد ونتجاهل المقاطع التي ليس فيها كلام. */
    private byte[] finish() {
        if (!smart) {                       // كلاسيكي: كل المقطع كما هو
            byte[] all = join(frames, 0, frames.size());
            reset();
            return all;
        }
        int end = frames.size() - Math.max(0, silent - TAIL_KEEP);
        byte[] out = voicedCount(0, end) >= MIN_SPEECH ? join(frames, 0, end) : null;
        reset();
        return out;
    }

    /** قطع إجباري عند أهدأ لحظة في آخر المقطع، مع ترحيل ما بعدها. */
    private byte[] forcedCut() {
        if (!smart) {                       // كلاسيكي: نقطع عند الحد تماماً بلا ترحيل
            byte[] all = join(frames, 0, frames.size());
            reset();
            return all;
        }
        int size = frames.size();
        int lo = Math.max(lead + minFrames - 1, size - CUT_WINDOW);
        int best = size - 1;
        double bestE = Double.MAX_VALUE;
        for (int i = lo; i < size; i++) {
            double e = energy.get(i);
            if (e <= bestE) {      // عند التساوي نفضّل الأحدث (أقل تأخيراً)
                bestE = e;
                best = i;
            }
        }
        int cutAt = best + 1;
        byte[] out = join(frames, 0, cutAt);
        if (cutAt >= size) {
            reset();
            return out;
        }
        // نرحّل الباقي ليكون بداية المقطع التالي
        ArrayList<byte[]> rf = new ArrayList<>(frames.subList(cutAt, size));
        ArrayList<Double> re = new ArrayList<>(energy.subList(cutAt, size));
        ArrayList<Boolean> rv = new ArrayList<>(voiced.subList(cutAt, size));
        frames.clear();
        energy.clear();
        voiced.clear();
        frames.addAll(rf);
        energy.addAll(re);
        voiced.addAll(rv);
        lead = 0;
        silent = 0;
        for (int i = voiced.size() - 1; i >= 0 && !voiced.get(i); i--) silent++;
        return out;
    }
}
