package com.elwalid.dualsub;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioPlaybackCaptureConfiguration;
import android.media.AudioRecord;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

public class TranslateService extends Service {
    static final String ACTION_START = "com.elwalid.dualsub.START";
    static final String ACTION_STOP = "com.elwalid.dualsub.STOP";

    private static final String CHANNEL = "dualsub";
    private static final int SAMPLE_RATE = 16000;
    // النموذج الأدق أولاً، ثم الأسرع عند بلوغ الحد المجاني (لكل نموذج حد مستقل)
    private static final String[] STT_MODELS = {"whisper-large-v3", "whisper-large-v3-turbo"};
    private static final String GROQ_LLM = "llama-3.3-70b-versatile";
    private static final String[] GEMINI_MODELS = {"gemini-flash-latest", "gemini-flash-lite-latest", "gemini-2.5-flash"};
    private static final String GEMINI_BASE = "https://generativelanguage.googleapis.com/v1beta/models/";
    private static final String UA = "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36";
    private static final int MAX_PENDING = 8;      // أقصى عدد مقاطع تنتظر المعالجة، حتى لا يتراكم التأخير
    private static final int HISTORY_SIZE = 3;     // عدد الجمل السابقة المستخدمة كسياق

    private static final Map<String, String> LANG_CODES = new HashMap<>();
    static {
        String[] kv = {"english", "en", "french", "fr", "spanish", "es", "german", "de", "turkish", "tr",
                "russian", "ru", "italian", "it", "portuguese", "pt", "arabic", "ar", "hindi", "hi",
                "japanese", "ja", "korean", "ko", "chinese", "zh", "persian", "fa", "urdu", "ur",
                "dutch", "nl", "polish", "pl", "indonesian", "id", "ukrainian", "uk", "greek", "el",
                "swedish", "sv", "romanian", "ro", "czech", "cs", "hebrew", "he", "thai", "th",
                "vietnamese", "vi", "malay", "ms", "bengali", "bn", "hungarian", "hu"};
        for (int i = 0; i + 1 < kv.length; i += 2) LANG_CODES.put(kv[i], kv[i + 1]);
    }

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService net = Executors.newSingleThreadExecutor();
    private final AtomicInteger pending = new AtomicInteger(0);

    private MediaProjection projection;
    private AudioRecord record;
    private Thread capThread;
    private volatile boolean running = false;
    private volatile int maxSegSeconds = 5;

    private WindowManager wm;
    private WindowManager.LayoutParams lp;
    private SharedPreferences prefs;
    private LinearLayout overlay;
    private TextView origTv, transTv;
    private volatile boolean showOrig = true;
    private volatile int mode = 0;                  // 0 أفلام ومسلسلات، 1 أخبار وبث مباشر، 2 وثائقي وبرامج، 3 عام
    private volatile int segMin = 10, segEnd = 5;    // أقل طول للمقطع، وإطارات الصمت التي تنهي الجملة (100 مللي ثانية لكل إطار)
    private volatile boolean progressive = false;   // عرض الترجمة تدريجياً (تجريبي، مغلق افتراضياً)
    private volatile boolean lookahead = false;      // انتظار الجملة التالية قبل الترجمة (دقة أعلى، تأخير أكبر)
    private int fontSize = 19;
    private final Runnable hideRunnable = () -> {
        if (overlay == null) return;
        overlay.animate().cancel();
        overlay.animate().alpha(0f).setDuration(220).withEndAction(() -> {
            if (overlay != null && overlay.getAlpha() < 0.05f) overlay.setVisibility(View.GONE);
        }).start();
    };

    private String groqKey = "";     // يُستخرج من أي خانة تبدأ بـ gsk_
    private String gemKey = "";      // يُستخرج من أي مفتاح آخر (Gemini)
    private final long[] sttBackoff = new long[STT_MODELS.length];
    private volatile long gemBackoff = 0, groqLlmBackoff = 0;
    private volatile boolean geminiThinkingCfg = true;   // نحاول تعطيل «التفكير» لتسريع Gemini
    private volatile double segSeconds = 3;              // مدة الجملة الحالية (لتحديد عدد الأحرف المسموح)
    private final LinkedHashMap<String, String> glossary = new LinkedHashMap<>();   // أسماء ومصطلحات ثابتة
    private String srcLang = "";     // لغة الفيديو إن حددها المستخدم
    private String targetLang = "ar";

    // حالة الجلسة (تُستخدم في خيط الشبكة فقط)
    private String lockedLang = null, lastDetected = null;
    private int detectCount = 0;
    private String prevText = "";
    private final ArrayDeque<String> history = new ArrayDeque<>();
    private final Lookahead look = new Lookahead();
    private static final long LOOKAHEAD_WAIT_MS = 3500;   // أقصى انتظار للجملة التالية
    private int streamFails = 0;                          // بث الترجمة: بعد 3 إخفاقات متتالية نعطله
    private String lastPartial = "";
    private long lastPartialAt = 0;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || ACTION_STOP.equals(intent.getAction())) {
            stopEverything();
            stopSelf();
            return START_NOT_STICKY;
        }
        if (running) return START_NOT_STICKY;

        prefs = getSharedPreferences("cfg", MODE_PRIVATE);
        groqKey = "";
        gemKey = "";
        for (String k : new String[]{prefs.getString("key", "").trim(), prefs.getString("gkey", "").trim()}) {
            if (k.startsWith("gsk_")) groqKey = k;
            else if (!k.isEmpty()) gemKey = k;
        }
        for (int i = 0; i < sttBackoff.length; i++) sttBackoff[i] = 0;
        gemBackoff = 0;
        groqLlmBackoff = 0;
        srcLang = prefs.getString("src", "").trim().toLowerCase();
        targetLang = prefs.getString("lang", "ar");
        maxSegSeconds = Math.max(3, Math.min(10, prefs.getInt("maxseg5", 6)));
        mode = Math.max(0, Math.min(3, prefs.getInt("mode", 0)));
        if (mode == 1) { segMin = 8; segEnd = 4; }      // الأخبار: كلام متواصل، نقطع أسرع
        else { segMin = 10; segEnd = 5; }
        showOrig = prefs.getBoolean("showorig", false);
        lookahead = prefs.getBoolean("lookahead", false);
        progressive = prefs.getBoolean("progressive", false);
        fontSize = Math.max(12, Math.min(32, prefs.getInt("fsize", 20)));
        lockedLang = null; lastDetected = null; detectCount = 0; prevText = "";
        history.clear();
        look.clear();
        streamFails = 0;
        glossary.clear();
        pending.set(0);

        startForegroundWithNotification();

        int code = intent.getIntExtra("code", 0);
        Intent data = intent.getParcelableExtra("data");
        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        try {
            projection = mpm.getMediaProjection(code, data);
            projection.registerCallback(new MediaProjection.Callback() {
                @Override
                public void onStop() {
                    stopEverything();
                    stopSelf();
                }
            }, main);
        } catch (Exception e) {
            stopSelf();
            return START_NOT_STICKY;
        }

        createOverlay();
        startCapture();
        return START_NOT_STICKY;
    }

    /* ---------- الإشعار ---------- */
    private void startForegroundWithNotification() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "ترجمة الفيديو",
                NotificationManager.IMPORTANCE_LOW));
        Intent stop = new Intent(this, TranslateService.class).setAction(ACTION_STOP);
        PendingIntent pi = PendingIntent.getService(this, 0, stop, PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, CHANNEL)
                .setContentTitle("الترجمة تعمل")
                .setContentText("اضغط «إيقاف» لإنهاء الترجمة")
                .setSmallIcon(R.drawable.ic_stat)
                .addAction(new Notification.Action.Builder(null, "إيقاف", pi).build())
                .setOngoing(true)
                .build();
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
    }

    /* ---------- الشاشة العائمة ---------- */
    private void createOverlay() {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        float d = getResources().getDisplayMetrics().density;

        overlay = new LinearLayout(this);
        overlay.setOrientation(LinearLayout.VERTICAL);
        overlay.setPadding((int) (12 * d), (int) (8 * d), (int) (12 * d), (int) (8 * d));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.argb(140, 0, 0, 0));
        bg.setCornerRadius(10 * d);
        overlay.setBackground(bg);

        origTv = new TextView(this);
        origTv.setTextColor(Color.rgb(210, 210, 210));
        origTv.setTextSize(Math.max(11, fontSize * 0.72f));
        origTv.setGravity(Gravity.CENTER);

        transTv = new TextView(this);
        transTv.setTextColor(Color.WHITE);
        transTv.setShadowLayer(6f, 0f, 0f, Color.BLACK);
        transTv.setLineSpacing(0f, 1.1f);
        transTv.setTextSize(fontSize);
        transTv.setGravity(Gravity.CENTER);
        transTv.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        overlay.addView(origTv);
        overlay.addView(transTv);
        overlay.setVisibility(View.GONE);

        int width = (int) (getResources().getDisplayMetrics().widthPixels * 0.94f);
        lp = new WindowManager.LayoutParams(
                width, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        lp.y = loadY();
        overlay.setOnTouchListener(new View.OnTouchListener() {
            float downRawY;
            int startY;
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                int h = getResources().getDisplayMetrics().heightPixels;
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        downRawY = e.getRawY();
                        startY = lp.y;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        lp.y = Math.max(0, Math.min(h - 120, startY + (int) (e.getRawY() - downRawY)));
                        try { wm.updateViewLayout(overlay, lp); } catch (Exception ignored) {}
                        return true;
                    case MotionEvent.ACTION_UP:
                        prefs.edit().putInt(isLandscape() ? "y_land2" : "y_port2", lp.y).apply();
                        return true;
                }
                return false;
            }
        });
        wm.addView(overlay, lp);
    }

    private boolean isLandscape() {
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        return dm.widthPixels > dm.heightPixels;
    }

    private int loadY() {
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        boolean land = isLandscape();
        // مكان الترجمة المعتاد: أسفل الصورة كما في نتفلكس
        int def = land ? (int) (dm.heightPixels * 0.68) : (int) (dm.heightPixels * 0.34);
        return prefs == null ? def : prefs.getInt(land ? "y_land2" : "y_port2", def);
    }

    @Override
    public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        if (overlay != null && lp != null && wm != null) {
            lp.width = (int) (getResources().getDisplayMetrics().widthPixels * 0.94f);
            lp.y = loadY();
            try { wm.updateViewLayout(overlay, lp); } catch (Exception ignored) {}
        }
    }

    /** مدة بقاء الترجمة على الشاشة: بحسب سرعة قراءة مريحة (نحو 17 حرفاً في الثانية). */
    private static long holdFor(String s) {
        int n = s == null ? 0 : s.length();
        return Math.max(2800L, Math.min(9000L, 1200L + (long) (n / 17.0 * 1000)));
    }

    /** يقسم الجملة الطويلة إلى سطرين متوازنين عند أقرب فاصل طبيعي. */
    private static String twoLines(String t) {
        if (t == null) return "";
        t = t.replace("\n", " ").trim();
        if (t.length() <= 40) return t;
        int mid = t.length() / 2, best = -1, bestScore = Integer.MAX_VALUE;
        for (int i = 1; i < t.length() - 1; i++) {
            if (t.charAt(i) != ' ') continue;
            int score = Math.abs(i - mid);
            char p = t.charAt(i - 1);
            if (p == '،' || p == ',' || p == '.' || p == '؟' || p == '!' || p == ':') score -= 6;
            if (score < bestScore) { bestScore = score; best = i; }
        }
        return best < 0 ? t : t.substring(0, best).trim() + "\n" + t.substring(best + 1).trim();
    }

    private String glossaryVocab() {
        StringBuilder sb = new StringBuilder();
        for (String k : glossary.keySet()) {
            if (sb.length() + k.length() > 120) break;
            if (sb.length() > 0) sb.append(", ");
            sb.append(k);
        }
        return sb.toString();
    }

    private void showText(String orig, String trans, long holdMs) {
        main.post(() -> {
            if (overlay == null) return;
            origTv.setText(orig);
            origTv.setVisibility(!showOrig || orig == null || orig.isEmpty() ? View.GONE : View.VISIBLE);
            transTv.setText(trans);
            overlay.animate().cancel();
            if (overlay.getVisibility() != View.VISIBLE) overlay.setAlpha(0f);
            overlay.setVisibility(View.VISIBLE);
            overlay.animate().alpha(1f).setDuration(160).start();
            main.removeCallbacks(hideRunnable);
            main.postDelayed(hideRunnable, holdMs);
        });
    }

    /* ---------- التقاط الصوت وتقطيعه عند توقف الكلام ---------- */
    private void startCapture() {
        AudioPlaybackCaptureConfiguration cfg = new AudioPlaybackCaptureConfiguration.Builder(projection)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build();
        AudioFormat fmt = new AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(SAMPLE_RATE)
                .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                .build();
        int min = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT);
        try {
            record = new AudioRecord.Builder()
                    .setAudioFormat(fmt)
                    .setBufferSizeInBytes(Math.max(min, SAMPLE_RATE * 2))
                    .setAudioPlaybackCaptureConfig(cfg)
                    .build();
            record.startRecording();
        } catch (Exception e) {
            showText("", "تعذّر بدء التقاط الصوت: " + e.getMessage(), 6000);
            return;
        }
        running = true;
        capThread = new Thread(this::captureLoop, "dualsub-capture");
        capThread.start();
    }

    private void captureLoop() {
        final int frameBytes = SAMPLE_RATE / 10 * 2;   // 100 ms
        final int softCutFrames = 30;                  // بعد 3 ثوانٍ نكتفي بوقفة 0.3 ثانية
        final int softSilenceFrames = 3;
        final int maxFrames = maxSegSeconds * 10;
        final byte[] frame = new byte[frameBytes];
        // المقطّع: يقطع عند الوقفات الطبيعية، وإن طال الكلام يقطع عند أهدأ لحظة ويرحّل الباقي
        final Segmenter segmenter = new Segmenter(segMin, segEnd, softCutFrames, softSilenceFrames, maxFrames);
        double noise = 60;                             // تقدير ضجيج الخلفية

        while (running) {
            int off = 0;
            while (running && off < frameBytes) {
                int n = record.read(frame, off, frameBytes - off);
                if (n <= 0) break;
                off += n;
            }
            if (!running) break;
            if (off < frameBytes) {
                try { Thread.sleep(50); } catch (InterruptedException ignored) {}
                continue;
            }
            byte[] f = frame.clone();
            double r = rms(f);
            // عتبة تتكيف مع ضجيج الخلفية (موسيقى مثلاً)
            double thr = Math.max(150, Math.min(400, noise * 2.5));
            boolean speech = r >= thr;
            noise = r < noise ? noise * 0.8 + r * 0.2 : noise * 0.997 + r * 0.003;

            final byte[] pcm = segmenter.push(f, r, speech);
            if (pcm == null) continue;
            if (pending.get() >= MAX_PENDING) continue;   // الشبكة متوقفة تماماً: نتخطى المقطع
            final long queuedAt = System.currentTimeMillis();
            pending.incrementAndGet();
            net.execute(() -> {
                try {
                    // ترجمة متأخرة أكثر من 12 ثانية لا فائدة منها: نتخطاها لنلحق بالصوت
                    if (System.currentTimeMillis() - queuedAt > 12000) return;
                    process(pcm);
                } finally {
                    pending.decrementAndGet();
                }
            });
        }
    }

    private static double rms(byte[] pcm) {
        ByteBuffer bb = ByteBuffer.wrap(pcm).order(ByteOrder.LITTLE_ENDIAN);
        long sum = 0;
        int n = pcm.length / 2;
        for (int i = 0; i < n; i++) {
            int s = bb.getShort();
            sum += (long) s * s;
        }
        return n == 0 ? 0 : Math.sqrt((double) sum / n);
    }

    /** يرفع مستوى الصوت الخافت قبل إرساله، فيتحسن التعرف على الكلام. */
    private static byte[] normalize(byte[] pcm) {
        int n = pcm.length / 2;
        if (n == 0) return pcm;
        ByteBuffer in = ByteBuffer.wrap(pcm).order(ByteOrder.LITTLE_ENDIAN);
        int peak = 1;
        for (int i = 0; i < n; i++) {
            int a = Math.abs((int) in.getShort(i * 2));
            if (a > peak) peak = a;
        }
        float gain = 20000f / peak;
        if (gain < 1.3f) return pcm;
        if (gain > 10f) gain = 10f;
        byte[] out = new byte[pcm.length];
        ByteBuffer ob = ByteBuffer.wrap(out).order(ByteOrder.LITTLE_ENDIAN);
        for (int i = 0; i < n; i++) {
            int v = Math.round(in.getShort(i * 2) * gain);
            if (v > 32767) v = 32767;
            if (v < -32768) v = -32768;
            ob.putShort(i * 2, (short) v);
        }
        return out;
    }

    /* ---------- المعالجة ---------- */
    private static class AuthException extends Exception {}
    private static class RateException extends Exception {
        final int secs;
        RateException(int secs) { this.secs = secs; }
    }

    private boolean groqSttAvailable(long now) {
        if (groqKey.isEmpty()) return false;
        for (long b : sttBackoff) if (now >= b) return true;
        return false;
    }

    private void process(byte[] rawPcm) {
        if (!running) return;
        long now = System.currentTimeMillis();
        segSeconds = rawPcm.length / 32000.0;
        try {
            if (groqKey.isEmpty() && gemKey.isEmpty()) {
                showText("", "أدخل المفتاح في التطبيق أولاً.", 5000);
                return;
            }
            byte[] pcm = normalize(rawPcm);
            boolean groqOk = groqSttAvailable(now);
            boolean gemOk = !gemKey.isEmpty() && now >= gemBackoff;
            if (groqOk) {
                String text = null;
                boolean got = false;
                try {
                    text = groqTranscribeAny(pcm, now);
                    got = true;
                } catch (AuthException e) {
                    groqKey = "";                    // مفتاح غير صالح: نتجاهله
                    if (!gemOk) throw e;
                } catch (RateException e) {
                    if (!gemOk) throw e;
                } catch (Exception e) {
                    if (!gemOk) throw e;
                }
                if (got) {
                    handleText(text);
                    return;
                }
            }
            if (gemOk) {
                try {
                    geminiAll(pcm);
                } catch (RateException e) {
                    gemBackoff = now + e.secs * 1000L;
                    throw e;
                }
            } else if (!groqOk) {
                // كل الخدمات في فترة انتظار بسبب الحد المجاني
                showText("", "بلغت حد الاستخدام المجاني مؤقتاً. ستعود الترجمة تلقائياً بعد لحظات.", 4000);
            }
        } catch (AuthException e) {
            showText("", "المفتاح غير صحيح. عدّله من التطبيق.", 8000);
        } catch (RateException e) {
            showText("", "بلغت حد الاستخدام المجاني. تعود الترجمة بعد " + e.secs + " ثانية.", 6000);
        } catch (Exception e) {
            String m = String.valueOf(e.getMessage());
            if (m.startsWith("Gemini 50")) {
                showText("", "خدمة Gemini مشغولة الآن. سأحاول مع الجملة التالية.", 4000);
                return;
            }
            if (m.length() > 160) m = m.substring(0, 160);
            showText("", "خطأ: " + e.getClass().getSimpleName() + " " + m, 10000);
        }
    }

    /** يعرض النص الأصلي فور تفريغه، ثم الترجمة حين تجهز (تدريجياً أثناء وصولها). */
    private void handleText(String text) {
        if (text == null) return;
        text = text.trim();
        if (text.length() < 2 || isHallucination(text) || text.equals(prevText)) return;
        if (Filters.isEcho(text, prevText, history)) return;     // صدى السياق الذي أرسلناه لـ Whisper
        prevText = text;
        if (!lookahead) {
            if (showOrig) showText(text, "...", 9000);
            translateAndShow(text, null);
            return;
        }
        // وضع الجملة التالية: نحتجز هذه الجملة حتى تصل التي بعدها (أو تنتهي المهلة)
        final long tk = look.onNew(text, segSeconds, this::translateHeld);
        main.postDelayed(() -> {
            try {
                net.execute(() -> {
                    if (running) look.flush(tk, this::translateHeld);
                });
            } catch (Exception ignored) {
            }
        }, LOOKAHEAD_WAIT_MS);
    }

    private void translateHeld(String text, String next, double secs) {
        segSeconds = secs;
        translateAndShow(text, next);
    }

    private void translateAndShow(String text, String next) {
        String eff = !srcLang.isEmpty() ? srcLang : lockedLang;
        if (eff != null && eff.equals(targetLang)) {          // لغة الفيديو هي لغة الهدف: نعرضه دون ترجمة
            remember(text);
            String same = twoLines(text);
            showText(text, same, holdFor(same));
            return;
        }
        String tr;
        try {
            tr = translateSmart(text, next, text);
        } catch (Exception e) {
            tr = "(تعذّرت الترجمة)";
        }
        remember(text);
        if (tr == null || tr.trim().isEmpty()) {
            main.post(hideRunnable);       // موسيقى أو صوت بلا كلام: لا نعرض شيئاً
            return;
        }
        tr = twoLines(tr);
        showText(text, tr, holdFor(tr));
    }

    private void remember(String text) {
        history.addLast(text);
        while (history.size() > HISTORY_SIZE) history.removeFirst();
    }

    private String contextText() {
        StringBuilder sb = new StringBuilder();
        for (String h : history) {
            if (sb.length() > 0) sb.append(" | ");
            sb.append(h);
        }
        return sb.toString();
    }

    private static boolean isHallucination(String t) {
        return Filters.isHallucination(t);
    }

    private String targetName() {
        return "ar".equals(targetLang) ? "Modern Standard Arabic (فصحى, not a dialect)"
                : "the language with ISO code '" + targetLang + "'";
    }

    /* --- Groq: نجرب النموذج الأدق ثم الأسرع إذا بلغ الأول حده --- */
    private String groqTranscribeAny(byte[] pcm, long now) throws Exception {
        RateException lastRate = null;
        for (int i = 0; i < STT_MODELS.length; i++) {
            if (now < sttBackoff[i]) continue;
            try {
                return groqTranscribe(pcm, STT_MODELS[i]);
            } catch (RateException e) {
                sttBackoff[i] = now + e.secs * 1000L;
                lastRate = e;
            }
        }
        throw lastRate != null ? lastRate : new RateException(10);
    }

    /* --- Groq: تفريغ الصوت مع سياق الجمل السابقة وتثبيت اللغة --- */
    private String groqTranscribe(byte[] pcm, String model) throws Exception {
        byte[] wav = toWav(pcm);
        String boundary = "----dualsub" + System.nanoTime();
        HttpURLConnection c = (HttpURLConnection) new URL(
                "https://api.groq.com/openai/v1/audio/transcriptions").openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(8000);
        c.setReadTimeout(15000);
        c.setDoOutput(true);
        c.setRequestProperty("Authorization", "Bearer " + groqKey);
        c.setRequestProperty("User-Agent", UA);
        c.setRequestProperty("Accept", "application/json");
        c.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);

        String lang = !srcLang.isEmpty() ? srcLang : lockedLang;
        String ctxAll = contextText();
        try (OutputStream os = c.getOutputStream()) {
            writeField(os, boundary, "model", model);
            writeField(os, boundary, "response_format", "verbose_json");
            writeField(os, boundary, "temperature", "0");
            if (lang != null && !lang.isEmpty()) writeField(os, boundary, "language", lang);
            // مفردات الأسماء الثابتة ثم آخر الجمل: تساعد Whisper على كتابة الأسماء بشكل صحيح
            String vocab = glossaryVocab();
            String ctxTail = ctxAll.length() > 200 ? ctxAll.substring(ctxAll.length() - 200) : ctxAll;
            String wprompt = (vocab.isEmpty() ? "" : vocab + ". ") + ctxTail;
            if (!wprompt.trim().isEmpty()) writeField(os, boundary, "prompt", wprompt);
            os.write(("--" + boundary + "\r\nContent-Disposition: form-data; name=\"file\"; "
                    + "filename=\"a.wav\"\r\nContent-Type: audio/wav\r\n\r\n").getBytes("UTF-8"));
            os.write(wav);
            os.write(("\r\n--" + boundary + "--\r\n").getBytes("UTF-8"));
        }

        int code = c.getResponseCode();
        if (code == 401) throw new AuthException();
        if (code == 429) {
            int ra = 20;
            try { ra = Integer.parseInt(c.getHeaderField("retry-after").trim()); } catch (Exception ignored) {}
            throw new RateException(Math.max(3, Math.min(ra, 60)));
        }
        if (code != 200) {
            String eb = errBody(c);
            if (eb.length() > 140) eb = eb.substring(0, 140);
            throw new Exception("Groq " + code + ": " + eb);
        }

        JSONObject json = new JSONObject(readAll(c.getInputStream()));
        JSONArray segs = json.optJSONArray("segments");
        String text;
        if (segs == null) {
            text = json.optString("text", "");
        } else {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < segs.length(); i++) {
                JSONObject s = segs.getJSONObject(i);
                double ns = s.optDouble("no_speech_prob", 0);
                double lp2 = s.optDouble("avg_logprob", 0);
                double cr = s.optDouble("compression_ratio", 0);     // نسبة عالية = تكرار مريب
                if (ns < 0.7 && lp2 > -1.6 && cr < 2.4) sb.append(s.optString("text", "")).append(' ');
            }
            text = sb.toString();
        }

        // تثبيت اللغة بعد كشفها مرتين متتاليتين
        if (srcLang.isEmpty() && lockedLang == null && text.trim().length() >= 10) {
            String code2 = LANG_CODES.get(json.optString("language", "").toLowerCase());
            if (code2 != null) {
                if (code2.equals(lastDetected)) detectCount++;
                else { lastDetected = code2; detectCount = 1; }
                if (detectCount >= 2) lockedLang = code2;
            }
        }
        return text;
    }

    /* ---------- الترجمة: Gemini ثم Groq (نموذج لغوي) ثم Google المجانية ---------- */
    /** تعليمات إضافية بحسب نوع ما يشاهده المستخدم. */
    private String modeNotes() {
        switch (mode) {
            case 1:
                return "- This is a live NEWS broadcast. Use formal news Arabic like Al Jazeera or BBC Arabic. "
                        + "Write organizations, countries and well-known acronyms by their usual Arabic names "
                        + "(NATO = الناتو, FBI = مكتب التحقيقات الفيدرالي). Keep numbers, dates, amounts and units exact. "
                        + "Transliterate names of people and places consistently.\n";
            case 2:
                return "- This is a documentary or talk programme. Use a clear explanatory tone, keep technical terms accurate, "
                        + "and keep the speaker's line of reasoning.\n";
            case 3:
                return "";
            default:
                return "- This is dialogue from a film or TV series. Preserve each speaker's tone and emotion (anger, sarcasm, "
                        + "tenderness, humor). Render slang and idioms by their natural meaning in clear, simple Modern Standard Arabic, "
                        + "not literally. Keep profanity meaningful but mild enough for subtitles. Never add narration or explanations.\n";
        }
    }

    private String translatePrompt(String text, String next) {
        String ctx = contextText();
        int budget = (int) Math.max(24, Math.min(84, Math.round(Math.max(1.5, segSeconds) * 17)));
        StringBuilder p = new StringBuilder();
        p.append("You are a senior Netflix subtitle translator. Translate the sentence below into ")
                .append(targetName()).append(".\n");
        p.append("Rules:\n");
        p.append("- Translate meaning, tone and register, not word for word. Natural, fluent, no dialect, no filler words.\n");
        p.append("- Be concise: at most ").append(budget).append(" characters on one line (no line breaks). Condense without losing the meaning.\n");
        p.append("- The text comes from automatic speech recognition and may have wrong words or missing punctuation: ")
                .append("use the context to repair obvious mistakes, and infer questions and exclamations (؟ !) from the context.\n");
        p.append("- Keep names consistent with the glossary. Transliterate people's names into Arabic letters, keep brand names, ")
                .append("write numbers with digits 0-9, use Arabic punctuation (، ؟).\n");
        p.append("- Do not describe sounds, do not use brackets, and never explain or comment.\n");
        p.append("- If the sentence is an incomplete fragment, translate the fragment as it is.\n");
        p.append("- If it is only music, a sound effect or a filler (um, uh), return an empty string.\n");
        p.append(modeNotes());
        if (!glossary.isEmpty()) {
            p.append("\nGlossary (source => Arabic):\n");
            for (Map.Entry<String, String> e : glossary.entrySet()) {
                p.append(e.getKey()).append(" => ").append(e.getValue()).append('\n');
            }
        }
        if (!ctx.isEmpty()) p.append("\nPrevious sentences (context only, do not translate them): ").append(ctx).append('\n');
        if (next != null && !next.isEmpty()) {
            p.append("\nNext sentence (context only, do not translate it; use it to resolve ambiguous words and pronouns): ")
                    .append(next).append('\n');
        }
        p.append("\nReturn ONLY JSON: {\"t\": \"<the translation>\", \"g\": {\"term\": \"Arabic\"}} ")
                .append("(g = new or changed names and terms only; leave it empty if none).\n\n")
                .append("Sentence to translate: ").append(text);
        return p.toString();
    }

    /** يقرأ رد النموذج: JSON فيه الترجمة والمسرد، أو نصاً عادياً إن لم يلتزم بالصيغة. */
    private String parseTranslation(String out) {
        if (out == null) return null;
        String s = out.trim();
        int a = s.indexOf('{'), b = s.lastIndexOf('}');
        if (a >= 0 && b > a) {
            try {
                JSONObject j = new JSONObject(s.substring(a, b + 1));
                if (j.has("t")) {
                    JSONObject g = j.optJSONObject("g");
                    if (g != null) {
                        java.util.Iterator<String> it = g.keys();
                        while (it.hasNext()) {
                            String k = it.next();
                            String v = g.optString(k, "").trim();
                            if (!k.trim().isEmpty() && !v.isEmpty() && glossary.size() < 40) glossary.put(k.trim(), v);
                        }
                    }
                    return j.optString("t", "").trim();
                }
            } catch (Exception ignored) {
            }
        }
        if (s.startsWith("{")) return null;      // JSON تالف: نجرب الخدمة التالية
        return s;
    }

    private String translateSmart(String text, String next, String orig) throws Exception {
        String prompt = translatePrompt(text, next);
        lastPartial = "";
        lastPartialAt = 0;
        if (!gemKey.isEmpty() && System.currentTimeMillis() >= gemBackoff) {
            try {
                String tr = geminiStream(prompt, orig);       // نعرض الكلمات فور وصولها
                if (tr != null) return tr;
            } catch (RateException r) {
                gemBackoff = System.currentTimeMillis() + r.secs * 1000L;   // ننتقل للخدمة التالية
            } catch (Exception ignored) {
            }
            if (System.currentTimeMillis() >= gemBackoff) {
                try {
                    String out = geminiGenerate(gemKey, new JSONArray().put(new JSONObject().put("text", prompt)));
                    String tr = parseTranslation(out);
                    if (tr != null) return tr;
                } catch (RateException r) {
                    gemBackoff = System.currentTimeMillis() + r.secs * 1000L;
                } catch (Exception ignored) {
                }
            }
        }
        if (!groqKey.isEmpty() && System.currentTimeMillis() >= groqLlmBackoff) {
            try {
                String tr = groqStream(prompt, orig);
                if (tr != null) return tr;
            } catch (RateException r) {
                groqLlmBackoff = System.currentTimeMillis() + r.secs * 1000L;
            } catch (Exception ignored) {
            }
            if (System.currentTimeMillis() >= groqLlmBackoff) {
                try {
                    String out = groqChat(prompt);
                    String tr = parseTranslation(out);
                    if (tr != null) return tr;
                } catch (RateException r) {
                    groqLlmBackoff = System.currentTimeMillis() + r.secs * 1000L;
                } catch (Exception ignored) {
                }
            }
        }
        return googleTranslate(text);
    }

    /** يعرض ما وصل من الترجمة حتى الآن (دون تقسيم الأسطر، حتى لا تقفز الكلمات). */
    private void showPartial(String orig, String acc) {
        if (!progressive) return;     // الأصل: يظهر السطر كاملاً دفعة واحدة كما في نتفلكس
        StreamUtil.Partial p = StreamUtil.partialT(acc);
        if (p == null) return;
        String t = p.text.trim();
        if (t.isEmpty() || t.equals(lastPartial)) return;
        long now = System.currentTimeMillis();
        if (!p.done && now - lastPartialAt < 80) return;
        lastPartial = t;
        lastPartialAt = now;
        showText(orig, t, 9000);
    }

    /** ترجمة Gemini ببث تدريجي. يعيد null إذا تعذّر البث، فنرجع للطريقة العادية. */
    private String geminiStream(String prompt, String orig) throws Exception {
        if (streamFails >= 3) return null;
        JSONArray parts = new JSONArray().put(new JSONObject().put("text", prompt));
        Exception last = null;
        for (String model : GEMINI_MODELS) {
            for (int attempt = 0; attempt < 2; attempt++) {
                byte[] payload = geminiBody(parts, geminiThinkingCfg);
                HttpURLConnection c = (HttpURLConnection) new URL(
                        GEMINI_BASE + model + ":streamGenerateContent?alt=sse").openConnection();
                c.setRequestMethod("POST");
                c.setConnectTimeout(8000);
                c.setReadTimeout(14000);
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/json");
                c.setRequestProperty("x-goog-api-key", gemKey);
                c.setRequestProperty("User-Agent", UA);
                try (OutputStream os = c.getOutputStream()) {
                    os.write(payload);
                }
                int code = c.getResponseCode();
                if (code == 429) throw new RateException(20);
                if (code == 200) {
                    final StringBuilder acc = new StringBuilder();
                    StreamUtil.readSse(c.getInputStream(), d -> {
                        JSONObject j = new JSONObject(d);
                        JSONArray cand = j.optJSONArray("candidates");
                        if (cand != null && cand.length() > 0) {
                            JSONObject content = cand.getJSONObject(0).optJSONObject("content");
                            JSONArray ps = content == null ? null : content.optJSONArray("parts");
                            if (ps != null) {
                                for (int i = 0; i < ps.length(); i++) acc.append(ps.getJSONObject(i).optString("text", ""));
                            }
                        }
                        showPartial(orig, acc.toString());
                        return true;
                    });
                    if (acc.length() == 0) {
                        streamFails++;
                        return null;
                    }
                    String tr = parseTranslation(acc.toString());
                    streamFails = tr == null ? streamFails + 1 : 0;
                    return tr;
                }
                String eb = errBody(c);
                if (eb.length() > 140) eb = eb.substring(0, 140);
                last = new Exception("Gemini " + code + ": " + eb);
                if (code == 400 && geminiThinkingCfg) {
                    geminiThinkingCfg = false;   // النموذج لا يقبل إعداد التفكير: نعيد الطلب بدونه
                    continue;
                }
                if (code == 404 || code == 500 || code == 502 || code == 503 || code == 504) break;   // جرّب النموذج التالي
                throw last;                      // 400/401/403: مشكلة في المفتاح أو الطلب
            }
        }
        streamFails++;
        if (last != null) throw last;
        return null;
    }

    /** ترجمة Groq ببث تدريجي. يعيد null إذا تعذّر البث. */
    private String groqStream(String prompt, String orig) throws Exception {
        if (streamFails >= 3) return null;
        JSONObject body = new JSONObject()
                .put("model", GROQ_LLM)
                .put("temperature", 0)
                .put("stream", true)
                .put("messages", new JSONArray().put(new JSONObject().put("role", "user").put("content", prompt)));
        byte[] payload = body.toString().getBytes("UTF-8");
        HttpURLConnection c = (HttpURLConnection) new URL("https://api.groq.com/openai/v1/chat/completions").openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(8000);
        c.setReadTimeout(12000);
        c.setDoOutput(true);
        c.setRequestProperty("Authorization", "Bearer " + groqKey);
        c.setRequestProperty("Content-Type", "application/json");
        c.setRequestProperty("User-Agent", UA);
        try (OutputStream os = c.getOutputStream()) {
            os.write(payload);
        }
        int code = c.getResponseCode();
        if (code == 429) {
            int ra = 20;
            try { ra = Integer.parseInt(c.getHeaderField("retry-after").trim()); } catch (Exception ignored) {}
            throw new RateException(Math.max(3, Math.min(ra, 60)));
        }
        if (code != 200) {
            streamFails++;
            throw new Exception("GroqChat " + code);
        }
        final StringBuilder acc = new StringBuilder();
        StreamUtil.readSse(c.getInputStream(), d -> {
            JSONObject j = new JSONObject(d);
            JSONArray ch = j.optJSONArray("choices");
            if (ch != null && ch.length() > 0) {
                JSONObject delta = ch.getJSONObject(0).optJSONObject("delta");
                if (delta != null) acc.append(delta.optString("content", ""));
            }
            showPartial(orig, acc.toString());
            return true;
        });
        if (acc.length() == 0) {
            streamFails++;
            return null;
        }
        String tr = parseTranslation(acc.toString());
        streamFails = tr == null ? streamFails + 1 : 0;
        return tr;
    }

    private String groqChat(String prompt) throws Exception {
        JSONObject body = new JSONObject()
                .put("model", GROQ_LLM)
                .put("temperature", 0)
                .put("messages", new JSONArray().put(new JSONObject().put("role", "user").put("content", prompt)));
        byte[] payload = body.toString().getBytes("UTF-8");
        HttpURLConnection c = (HttpURLConnection) new URL("https://api.groq.com/openai/v1/chat/completions").openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(8000);
        c.setReadTimeout(12000);
        c.setDoOutput(true);
        c.setRequestProperty("Authorization", "Bearer " + groqKey);
        c.setRequestProperty("Content-Type", "application/json");
        c.setRequestProperty("User-Agent", UA);
        try (OutputStream os = c.getOutputStream()) {
            os.write(payload);
        }
        int code = c.getResponseCode();
        if (code == 429) {
            int ra = 20;
            try { ra = Integer.parseInt(c.getHeaderField("retry-after").trim()); } catch (Exception ignored) {}
            throw new RateException(Math.max(3, Math.min(ra, 60)));
        }
        if (code != 200) throw new Exception("GroqChat " + code);
        JSONObject json = new JSONObject(readAll(c.getInputStream()));
        JSONArray ch = json.optJSONArray("choices");
        if (ch == null || ch.length() == 0) return null;
        return ch.getJSONObject(0).getJSONObject("message").optString("content", "");
    }

    private String googleTranslate(String text) throws Exception {
        String url = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl="
                + URLEncoder.encode(targetLang, "UTF-8") + "&dt=t&q=" + URLEncoder.encode(text, "UTF-8");
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(8000);
        c.setReadTimeout(10000);
        c.setRequestProperty("User-Agent", UA);
        if (c.getResponseCode() != 200) throw new Exception("Translate " + c.getResponseCode());
        JSONArray root = new JSONArray(readAll(c.getInputStream()));
        JSONArray parts = root.getJSONArray(0);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < parts.length(); i++) {
            JSONArray p = parts.optJSONArray(i);
            if (p != null) sb.append(p.optString(0, ""));
        }
        return sb.toString();
    }

    /* --- Gemini: تفريغ وترجمة في طلب واحد (عند استخدام مفتاح Gemini وحده) --- */
    private void geminiAll(byte[] pcm) throws Exception {
        String b64 = android.util.Base64.encodeToString(toWav(pcm), android.util.Base64.NO_WRAP);
        String langHint = !srcLang.isEmpty() ? " The spoken language is '" + srcLang + "'." : "";
        String ctx = contextText();
        String prompt = "Transcribe the human speech in this audio exactly." + langHint
                + " Then translate it into " + targetName() + " in Netflix subtitle style: natural, concise (at most two short lines), keep names and numbers. "
                + modeNotes().replace("\n", " ")
                + "Reply with exactly two lines: line 1 = the original transcription, line 2 = the translation. "
                + "If there is no clear human speech (silence, music, noise), reply with only: NONE"
                + (ctx.isEmpty() ? "" : "\n\nPrevious sentences for context only (do not output them): " + ctx);
        JSONObject inline = new JSONObject().put("mime_type", "audio/wav").put("data", b64);
        JSONArray parts = new JSONArray()
                .put(new JSONObject().put("text", prompt))
                .put(new JSONObject().put("inline_data", inline));
        String out = geminiGenerate(gemKey, parts);
        if (out == null) return;
        out = out.trim();
        if (out.isEmpty() || out.startsWith("NONE")) return;
        String[] lines = out.split("\\r?\\n+", 2);
        String orig = lines[0].trim();
        String tr = lines.length > 1 ? lines[1].trim() : orig;
        if (orig.length() < 2 || isHallucination(orig) || orig.equals(prevText)) return;
        prevText = orig;
        remember(orig);
        showText(orig, tr, holdFor(tr));
    }

    private byte[] geminiBody(JSONArray parts, boolean withThinkingCfg) throws Exception {
        JSONObject gen = new JSONObject().put("temperature", 0);
        if (withThinkingCfg) {
            // تعطيل «التفكير» يقلل زمن الاستجابة كثيراً في الترجمة
            gen.put("thinkingConfig", new JSONObject().put("thinkingBudget", 0));
        }
        JSONObject body = new JSONObject()
                .put("contents", new JSONArray().put(new JSONObject().put("parts", parts)))
                .put("generationConfig", gen);
        return body.toString().getBytes("UTF-8");
    }

    private String geminiGenerate(String key, JSONArray parts) throws Exception {
        Exception last = null;
        for (String model : GEMINI_MODELS) {
            for (int attempt = 0; attempt < 2; attempt++) {
                byte[] payload = geminiBody(parts, geminiThinkingCfg);
                HttpURLConnection c = (HttpURLConnection) new URL(GEMINI_BASE + model + ":generateContent").openConnection();
                c.setRequestMethod("POST");
                c.setConnectTimeout(8000);
                c.setReadTimeout(14000);
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/json");
                c.setRequestProperty("x-goog-api-key", key);
                c.setRequestProperty("User-Agent", UA);
                try (OutputStream os = c.getOutputStream()) {
                    os.write(payload);
                }
                int code = c.getResponseCode();
                if (code == 429) throw new RateException(20);
                if (code == 200) {
                    JSONObject json = new JSONObject(readAll(c.getInputStream()));
                    JSONArray cand = json.optJSONArray("candidates");
                    if (cand == null || cand.length() == 0) return null;
                    JSONArray ps = cand.getJSONObject(0).getJSONObject("content").optJSONArray("parts");
                    if (ps == null || ps.length() == 0) return null;
                    return ps.getJSONObject(0).optString("text", "");
                }
                String eb = errBody(c);
                if (eb.length() > 140) eb = eb.substring(0, 140);
                last = new Exception("Gemini " + code + ": " + eb);
                if (code == 400 && geminiThinkingCfg) {
                    geminiThinkingCfg = false;   // النموذج لا يقبل إعداد التفكير: نعيد الطلب بدونه
                    continue;
                }
                if (code == 500 || code == 502 || code == 503 || code == 504) {
                    // مشغول مؤقتاً: نعيد المحاولة مرة قصيرة ثم ننتقل لنموذج آخر
                    try { Thread.sleep(600); } catch (InterruptedException ignored) {}
                    continue;
                }
                if (code == 404) break;   // النموذج غير متاح، جرّب التالي
                throw last;               // 400/401/403: مشكلة في المفتاح أو الطلب
            }
        }
        if (last != null) throw last;
        return null;
    }

    /* ---------- أدوات ---------- */
    private static void writeField(OutputStream os, String boundary, String name, String value) throws Exception {
        os.write(("--" + boundary + "\r\nContent-Disposition: form-data; name=\"" + name
                + "\"\r\n\r\n" + value + "\r\n").getBytes("UTF-8"));
    }

    private static String errBody(HttpURLConnection c) {
        try {
            InputStream es = c.getErrorStream();
            return es == null ? "" : readAll(es);
        } catch (Exception e) {
            return "";
        }
    }

    private static String readAll(InputStream in) throws Exception {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] b = new byte[4096];
        int n;
        while ((n = in.read(b)) > 0) bo.write(b, 0, n);
        in.close();
        return bo.toString("UTF-8");
    }

    private static byte[] toWav(byte[] pcm) {
        ByteBuffer bb = ByteBuffer.allocate(44 + pcm.length).order(ByteOrder.LITTLE_ENDIAN);
        bb.put("RIFF".getBytes()).putInt(36 + pcm.length).put("WAVE".getBytes());
        bb.put("fmt ".getBytes()).putInt(16).putShort((short) 1).putShort((short) 1)
                .putInt(SAMPLE_RATE).putInt(SAMPLE_RATE * 2).putShort((short) 2).putShort((short) 16);
        bb.put("data".getBytes()).putInt(pcm.length).put(pcm);
        return bb.array();
    }

    /* ---------- الإيقاف ---------- */
    private void stopEverything() {
        running = false;
        try { if (record != null) { record.stop(); record.release(); } } catch (Exception ignored) {}
        record = null;
        try { if (projection != null) projection.stop(); } catch (Exception ignored) {}
        projection = null;
        look.clear();
        main.removeCallbacksAndMessages(null);
        try { if (overlay != null && wm != null) wm.removeView(overlay); } catch (Exception ignored) {}
        overlay = null;
    }

    @Override
    public void onDestroy() {
        stopEverything();
        net.shutdownNow();
        super.onDestroy();
    }
}
