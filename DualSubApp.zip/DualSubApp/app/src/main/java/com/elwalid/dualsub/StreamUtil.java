package com.elwalid.dualsub;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

/** أدوات بث الترجمة: قراءة SSE واستخراج حقل الترجمة تدريجياً من JSON لم يكتمل بعد. */
final class StreamUtil {
    private StreamUtil() {}

    /** نتيجة جزئية: النص الظاهر حتى الآن، وهل انتهى الحقل. */
    static final class Partial {
        final String text;
        final boolean done;
        Partial(String text, boolean done) {
            this.text = text;
            this.done = done;
        }
    }

    interface DataHandler {
        /** يُستدعى لكل سطر data. يعيد false لإيقاف القراءة. */
        boolean onData(String data) throws Exception;
    }

    /** يقرأ تدفق Server-Sent Events ويمرر محتوى كل سطر data: */
    static void readSse(InputStream in, DataHandler h) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(in, "UTF-8"));
        try {
            String line;
            while ((line = br.readLine()) != null) {
                if (!line.startsWith("data:")) continue;
                String d = line.substring(5).trim();
                if (d.isEmpty()) continue;
                if (d.equals("[DONE]")) break;
                if (!h.onData(d)) break;
            }
        } finally {
            try { br.close(); } catch (IOException ignored) {}
        }
    }

    /**
     * يستخرج قيمة الحقل "t" من رد النموذج حتى لو لم يكتمل.
     * يتعامل مع ```json في البداية، ومع الرد النصي العادي (بلا JSON).
     * يعيد null إذا لم يبدأ الحقل بعد.
     */
    static Partial partialT(String acc) {
        if (acc == null) return null;
        String s = acc;
        int i = 0, n = s.length();
        while (i < n && Character.isWhitespace(s.charAt(i))) i++;
        if (s.startsWith("```", i)) {
            int nl = s.indexOf('\n', i);
            if (nl < 0) return null;
            i = nl + 1;
            while (i < n && Character.isWhitespace(s.charAt(i))) i++;
        }
        if (i >= n) return null;
        if (s.charAt(i) != '{') {
            // رد نصي عادي: كله ترجمة
            String plain = s.substring(i);
            int fence = plain.indexOf("```");
            if (fence >= 0) plain = plain.substring(0, fence);
            return new Partial(plain, false);
        }
        int k = s.indexOf("\"t\"", i);
        if (k < 0) return null;
        int p = k + 3;
        while (p < n && Character.isWhitespace(s.charAt(p))) p++;
        if (p >= n || s.charAt(p) != ':') return null;
        p++;
        while (p < n && Character.isWhitespace(s.charAt(p))) p++;
        if (p >= n || s.charAt(p) != '"') return null;
        p++;
        StringBuilder sb = new StringBuilder();
        while (p < n) {
            char c = s.charAt(p);
            if (c == '"') return new Partial(sb.toString(), true);
            if (c == '\\') {
                if (p + 1 >= n) break;
                char e = s.charAt(p + 1);
                switch (e) {
                    case 'n': sb.append('\n'); p += 2; continue;
                    case 't': sb.append(' '); p += 2; continue;
                    case 'r': p += 2; continue;
                    case '"': sb.append('"'); p += 2; continue;
                    case '\\': sb.append('\\'); p += 2; continue;
                    case '/': sb.append('/'); p += 2; continue;
                    case 'u':
                        if (p + 6 > n) return new Partial(sb.toString(), false);
                        try {
                            sb.append((char) Integer.parseInt(s.substring(p + 2, p + 6), 16));
                        } catch (NumberFormatException ex) {
                            return new Partial(sb.toString(), false);
                        }
                        p += 6;
                        continue;
                    default:
                        sb.append(e);
                        p += 2;
                        continue;
                }
            }
            sb.append(c);
            p++;
        }
        return new Partial(sb.toString(), false);
    }
}
