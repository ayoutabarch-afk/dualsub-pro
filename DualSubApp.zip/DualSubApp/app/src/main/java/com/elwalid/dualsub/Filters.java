package com.elwalid.dualsub;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

/** مرشحات النص الناتج عن التفريغ الصوتي: هلوسات Whisper المعروفة، والحلقات، وصدى السياق. */
final class Filters {
    private Filters() {}

    /** جمل جاهزة يخترعها Whisper حين يسمع صمتاً أو موسيقى (تطابق كامل). */
    private static final String[] EXACT = {
            "thank you for watching", "thanks for watching", "thank you for watching this video",
            "please subscribe", "like and subscribe", "subscribe to my channel", "subscribe to the channel",
            "see you in the next video", "i ll see you in the next video", "see you next time",
            "merci d avoir regardé cette vidéo", "merci d avoir regardé", "n oubliez pas de vous abonner",
            "gracias por ver el video", "gracias por ver", "suscríbete", "no olvides suscribirte",
            "izlediğiniz için teşekkürler", "abone olmayı unutmayın",
            "danke fürs zuschauen", "vielen dank fürs zuschauen",
            "спасибо за просмотр", "продолжение следует",
            "شكرا للمشاهدة", "شكرا لكم على المشاهدة", "شكرا على المشاهدة", "لا تنسوا الاشتراك في القناة",
            "اشتركوا في القناة", "اشترك في القناة", "ترجمة نانسي قنقر", "نانسي قنقر",
            "♪", "music", "musique", "música", "موسيقى", "applause", "تصفيق"
    };

    /** عبارات إن وردت في النص فهو غالباً ترجمة جاهزة مخترعة. */
    private static final String[] CONTAINS = {
            "amara org", "sous titrage", "sous titres", "subtitles by", "subtitled by", "subtítulos realizados",
            "altyazı", "untertitel der", "نانسي قنقر", "ترجمة نانسي", "تمت الترجمة بواسطة"
    };

    static String normalize(String s) {
        if (s == null) return "";
        StringBuilder sb = new StringBuilder();
        boolean space = true;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (Character.isLetterOrDigit(c)) {
                sb.append(Character.toLowerCase(c));
                space = false;
            } else if (!space) {
                sb.append(' ');
                space = true;
            }
        }
        return sb.toString().trim();
    }

    static boolean isHallucination(String text) {
        String n = normalize(text);
        if (n.isEmpty()) return true;                       // علامات فقط، بلا حروف
        for (String b : EXACT) {
            if (n.equals(normalize(b))) return true;
        }
        for (String c : CONTAINS) {
            if (n.contains(normalize(c))) return true;
        }
        return isLoop(n);
    }

    /** حلقة تكرار: كلمة أو كلمتان تتكرران مراراً (علامة هلوسة معروفة). */
    static boolean isLoop(String normalized) {
        String[] w = normalized.split(" ");
        if (w.length < 6) return false;
        Set<String> distinct = new HashSet<>();
        for (String x : w) distinct.add(x);
        return distinct.size() <= 2 || distinct.size() * 4 <= w.length;
    }

    /**
     * صدى: Whisper يعيد أحياناً نص السياق الذي أرسلناه إليه (خاصة مع الصوت الضعيف).
     * نعد النص صدى إن كان مطابقاً لجملة سابقة أو جزءاً منها، أو يحتويها كلها تقريباً.
     */
    static boolean isEcho(String text, String prev, Collection<String> history) {
        String n = normalize(text);
        if (n.length() < 12) return false;                  // الجمل القصيرة قد تتكرر فعلاً
        if (echoOf(n, normalize(prev))) return true;
        if (history != null) {
            for (String h : history) {
                if (echoOf(n, normalize(h))) return true;
            }
        }
        return false;
    }

    private static boolean echoOf(String n, String h) {
        if (h.length() < 8) return false;
        if (h.equals(n)) return true;
        if (h.contains(n)) return true;
        return n.contains(h) && h.length() * 10 >= n.length() * 8;
    }

    /**
     * يحذف تكرار عبارة (3 كلمات فأكثر) تأتي مباشرة بعد نفسها داخل النص الواحد، وهو خلل معروف في Whisper.
     * التكرار القصير (كلمة أو كلمتان) يُترك لأنه كثيراً ما يكون كلاماً حقيقياً مثل "Hey. Hey.".
     */
    static String collapseRepeats(String text) {
        if (text == null) return null;
        String[] w = text.trim().split("\\s+");
        java.util.ArrayList<String> out = new java.util.ArrayList<>(java.util.Arrays.asList(w));
        boolean changed = true;
        while (changed) {
            changed = false;
            for (int n = out.size() / 2; n >= 3 && !changed; n--) {
                for (int i = 0; i + 2 * n <= out.size() && !changed; i++) {
                    boolean same = true;
                    for (int k = 0; k < n; k++) {
                        if (!key(out.get(i + k)).equals(key(out.get(i + n + k)))) { same = false; break; }
                    }
                    if (same) {
                        for (int k = 0; k < n; k++) out.remove(i + n);
                        changed = true;
                    }
                }
            }
        }
        if (out.size() == w.length) return text;
        StringBuilder sb = new StringBuilder();
        for (String x : out) { if (sb.length() > 0) sb.append(' '); sb.append(x); }
        return sb.toString();
    }

    private static String key(String w) {
        return w.toLowerCase().replaceAll("[^\\p{L}\\p{N}']", "");
    }
}
